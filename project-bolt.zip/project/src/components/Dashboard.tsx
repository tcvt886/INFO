import React, { useState, useEffect } from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { BatteryCharging, MapPin, Wifi, Folder, Bot, Clock, Cloud, Home, Settings, Grid3X3, Cpu, HardDrive, Thermometer, Activity, Smartphone, Navigation, MessageSquare, Camera, Music, Phone, Mail, Calendar, Calculator, Image, Video, Download, Upload, Globe, Shield, Zap, Users, BookOpen, Gamepad2, ShoppingCart, Heart, Star, Bookmark, Search, Filter, MoreHorizontal, ChevronRight, Wifi as Wifi1, Wifi as Wifi2, WifiOff, Battery, BatteryLow, Volume2, VolumeX, Sun, Moon, Bluetooth, BluetoothOff } from "lucide-react";

interface SystemInfo {
  time: Date;
  battery: {
    level: number;
    charging: boolean;
  };
  location: {
    coords: string;
    city: string;
    loading: boolean;
  };
  signal: {
    strength: string;
    bars: number;
  };
  storage: {
    used: number;
    total: number;
  };
  memory: {
    used: number;
    total: number;
  };
  temperature: number;
  network: {
    connected: boolean;
    speed: string;
  };
  bluetooth: boolean;
  volume: number;
  brightness: number;
  darkMode: boolean;
}

const Dashboard = () => {
  const [currentView, setCurrentView] = useState<'home' | 'settings' | 'apps'>('home');
  const [searchQuery, setSearchQuery] = useState('');
  const [showAppModal, setShowAppModal] = useState<string | null>(null);
  const [systemInfo, setSystemInfo] = useState<SystemInfo>({
    time: new Date(),
    battery: { level: 0.78, charging: true },
    location: { coords: "Fetching...", city: "Loading...", loading: true },
    signal: { strength: "4G LTE", bars: 4 },
    storage: { used: 45.2, total: 128 },
    memory: { used: 3.2, total: 8 },
    temperature: 42,
    network: { connected: true, speed: "150 Mbps" },
    bluetooth: true,
    volume: 75,
    brightness: 80,
    darkMode: true
  });

  const [selectedCard, setSelectedCard] = useState<string | null>(null);

  // App functionality handlers
  const handleAppClick = (appName: string) => {
    setSelectedCard(appName);
    setTimeout(() => setSelectedCard(null), 200);
    
    // Simulate app opening
    setShowAppModal(appName);
    setTimeout(() => setShowAppModal(null), 2000);
    
    // Add specific functionality for each app
    switch(appName) {
      case 'Camera':
        // Request camera permission and simulate camera opening
        if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
          navigator.mediaDevices.getUserMedia({ video: true })
            .then(() => console.log('Camera access granted'))
            .catch(() => console.log('Camera access denied'));
        }
        break;
      case 'Calculator':
        // Open calculator functionality
        const result = prompt('Enter calculation (e.g., 2+2):');
        if (result) {
          try {
            const answer = eval(result);
            alert(`Result: ${answer}`);
          } catch (e) {
            alert('Invalid calculation');
          }
        }
        break;
      case 'Files':
        // Simulate file browser
        alert('Opening File Manager...\nRecent files:\n• Document.pdf\n• Photo.jpg\n• Music.mp3');
        break;
      case 'AI Chat':
        // Simulate AI chat
        const question = prompt('Ask AI anything:');
        if (question) {
          alert(`AI Response: I understand you asked "${question}". This is a demo response!`);
        }
        break;
      case 'Maps':
        // Open maps with current location
        if (navigator.geolocation) {
          navigator.geolocation.getCurrentPosition((pos) => {
            const { latitude, longitude } = pos.coords;
            window.open(`https://www.google.com/maps/@${latitude},${longitude},15z`, '_blank');
          });
        }
        break;
      case 'Phone':
        // Simulate phone dialer
        const number = prompt('Enter phone number:');
        if (number) {
          alert(`Calling ${number}...`);
        }
        break;
      case 'Mail':
        // Open email client
        window.open('mailto:', '_blank');
        break;
      case 'Calendar':
        // Show current date info
        const today = new Date();
        alert(`Today is ${today.toDateString()}\nTime: ${today.toLocaleTimeString()}`);
        break;
      case 'Music':
        // Simulate music player
        alert('🎵 Now Playing: Demo Song\n⏸️ Pause | ⏭️ Next | 🔀 Shuffle');
        break;
      case 'Gallery':
        // Simulate photo gallery
        alert('📸 Photo Gallery\nRecent photos:\n• Vacation_2024.jpg\n• Family_dinner.jpg\n• Sunset.jpg');
        break;
      default:
        alert(`Opening ${appName}...`);
    }
  };

  // Settings handlers
  const toggleBluetooth = () => {
    setSystemInfo(prev => ({
      ...prev,
      bluetooth: !prev.bluetooth
    }));
  };

  const toggleDarkMode = () => {
    setSystemInfo(prev => ({
      ...prev,
      darkMode: !prev.darkMode
    }));
    document.documentElement.classList.toggle('dark');
  };

  const adjustVolume = (delta: number) => {
    setSystemInfo(prev => ({
      ...prev,
      volume: Math.max(0, Math.min(100, prev.volume + delta))
    }));
  };

  const adjustBrightness = (delta: number) => {
    setSystemInfo(prev => ({
      ...prev,
      brightness: Math.max(0, Math.min(100, prev.brightness + delta))
    }));
  };

  useEffect(() => {
    const interval = setInterval(() => {
      setSystemInfo(prev => ({ ...prev, time: new Date() }));
    }, 1000);

    // Battery API
    if ('getBattery' in navigator) {
      (navigator as any).getBattery().then((battery: any) => {
        setSystemInfo(prev => ({
          ...prev,
          battery: { level: battery.level, charging: battery.charging }
        }));
      });
    }

    // Location API with reverse geocoding
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        async (pos) => {
          const { latitude, longitude } = pos.coords;
          const coords = `${latitude.toFixed(4)}, ${longitude.toFixed(4)}`;
          
          try {
            // Using a free geocoding service
            const response = await fetch(
              `https://api.bigdatacloud.net/data/reverse-geocode-client?latitude=${latitude}&longitude=${longitude}&localityLanguage=en`
            );
            const data = await response.json();
            const city = data.city || data.locality || data.principalSubdivision || "Unknown Location";
            
            setSystemInfo(prev => ({
              ...prev,
              location: { coords, city, loading: false }
            }));
          } catch (error) {
            setSystemInfo(prev => ({
              ...prev,
              location: { coords, city: "Location Services", loading: false }
            }));
          }
        },
        () => {
          setSystemInfo(prev => ({
            ...prev,
            location: { coords: "Unavailable", city: "Location Disabled", loading: false }
          }));
        }
      );
    }

    // Simulate system monitoring
    const systemInterval = setInterval(() => {
      setSystemInfo(prev => ({
        ...prev,
        temperature: 35 + Math.random() * 15,
        memory: { ...prev.memory, used: 2 + Math.random() * 4 },
        storage: { ...prev.storage, used: prev.storage.used + (Math.random() - 0.5) * 0.1 }
      }));
    }, 5000);

    return () => {
      clearInterval(interval);
      clearInterval(systemInterval);
    };
  }, []);

  const handleCardClick = (cardId: string) => {
    setSelectedCard(cardId);
    setTimeout(() => setSelectedCard(null), 200);
  };

  const getSignalIcon = () => {
    switch (systemInfo.signal.bars) {
      case 1: return <Wifi1 size={24} />;
      case 2: return <Wifi2 size={24} />;
      case 3: case 4: return <Wifi size={24} />;
      default: return <WifiOff size={24} />;
    }
  };

  const getBatteryIcon = () => {
    if (systemInfo.battery.charging) return <BatteryCharging size={24} />;
    if (systemInfo.battery.level < 0.2) return <BatteryLow size={24} />;
    return <Battery size={24} />;
  };

  const HomeView = () => (
    <div className="space-y-6">
      {/* Status Bar */}
      <div className="flex justify-between items-center text-sm">
        <div className="flex items-center space-x-2">
          <span>{systemInfo.time.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
        </div>
        <div className="flex items-center space-x-3">
          {getSignalIcon()}
          <span>{Math.round(systemInfo.battery.level * 100)}%</span>
          {getBatteryIcon()}
        </div>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {[
          { 
            icon: <Clock size={20} />, 
            label: "Time", 
            value: systemInfo.time.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            subtitle: systemInfo.time.toLocaleDateString([], { weekday: 'short' }),
            id: "time"
          },
          { 
            icon: getSignalIcon(), 
            label: "Signal", 
            value: systemInfo.signal.strength,
            subtitle: `${systemInfo.signal.bars}/4 bars`,
            id: "signal"
          },
          { 
            icon: getBatteryIcon(), 
            label: "Battery", 
            value: `${Math.round(systemInfo.battery.level * 100)}%`,
            subtitle: systemInfo.battery.charging ? "Charging" : "Discharging",
            id: "battery"
          },
          { 
            icon: <MapPin size={20} />, 
            label: "Location", 
            value: systemInfo.location.loading ? "Loading..." : systemInfo.location.city,
            subtitle: systemInfo.location.coords,
            id: "location"
          }
        ].map((item) => (
          <Card 
            key={item.id}
            className={`bg-gray-800/50 backdrop-blur-sm border-gray-700 transition-all duration-300 hover:bg-gray-700/50 hover:scale-105 cursor-pointer ${
              selectedCard === item.id ? 'scale-95 bg-gray-600/50' : ''
            }`}
            onClick={() => handleCardClick(item.id)}
          >
            <CardContent className="p-3">
              <div className="flex items-center space-x-2 mb-2">
                <div className="text-blue-400">{item.icon}</div>
                <span className="text-xs text-gray-400">{item.label}</span>
              </div>
              <p className="text-sm font-semibold text-white">{item.value}</p>
              <p className="text-xs text-gray-500">{item.subtitle}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* System Monitoring */}
      <Card className="bg-gray-800/50 backdrop-blur-sm border-gray-700">
        <CardContent className="p-4">
          <h3 className="text-lg font-semibold mb-4 flex items-center">
            <Activity className="mr-2 text-green-400" size={20} />
            System Monitor
          </h3>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span className="flex items-center"><HardDrive size={16} className="mr-1" /> Storage</span>
                <span>{systemInfo.storage.used.toFixed(1)}GB / {systemInfo.storage.total}GB</span>
              </div>
              <div className="w-full bg-gray-700 rounded-full h-2">
                <div 
                  className="bg-blue-500 h-2 rounded-full transition-all duration-500"
                  style={{ width: `${(systemInfo.storage.used / systemInfo.storage.total) * 100}%` }}
                ></div>
              </div>
            </div>
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span className="flex items-center"><Cpu size={16} className="mr-1" /> Memory</span>
                <span>{systemInfo.memory.used.toFixed(1)}GB / {systemInfo.memory.total}GB</span>
              </div>
              <div className="w-full bg-gray-700 rounded-full h-2">
                <div 
                  className="bg-green-500 h-2 rounded-full transition-all duration-500"
                  style={{ width: `${(systemInfo.memory.used / systemInfo.memory.total) * 100}%` }}
                ></div>
              </div>
            </div>
          </div>
          <div className="mt-4 flex justify-between items-center">
            <div className="flex items-center space-x-2">
              <Thermometer size={16} className="text-orange-400" />
              <span className="text-sm">Temperature: {systemInfo.temperature.toFixed(1)}°C</span>
            </div>
            <Badge variant={systemInfo.temperature > 50 ? "destructive" : "secondary"}>
              {systemInfo.temperature > 50 ? "Hot" : "Normal"}
            </Badge>
          </div>
        </CardContent>
      </Card>

      {/* App Grid */}
      <div className="grid grid-cols-4 gap-4">
        {[
          { icon: <Folder size={24} />, label: "Files", color: "text-yellow-400" },
          { icon: <Bot size={24} />, label: "AI Chat", color: "text-purple-400" },
          { icon: <Cloud size={24} />, label: "Cloud", color: "text-blue-400" },
          { icon: <Navigation size={24} />, label: "Maps", color: "text-green-400" },
          { icon: <Camera size={24} />, label: "Camera", color: "text-gray-400" },
          { icon: <Music size={24} />, label: "Music", color: "text-pink-400" },
          { icon: <Phone size={24} />, label: "Phone", color: "text-green-500" },
          { icon: <Mail size={24} />, label: "Mail", color: "text-red-400" },
          { icon: <Calendar size={24} />, label: "Calendar", color: "text-orange-400" },
          { icon: <Calculator size={24} />, label: "Calculator", color: "text-indigo-400" },
          { icon: <Image size={24} />, label: "Gallery", color: "text-cyan-400" },
          { icon: <MoreHorizontal size={24} />, label: "More", color: "text-gray-500" }
        ].map((app, index) => (
          <Card 
            key={app.label}
            className={`bg-gray-800/30 backdrop-blur-sm border-gray-700 transition-all duration-300 hover:bg-gray-700/50 hover:scale-110 cursor-pointer ${
              selectedCard === app.label ? 'scale-95 bg-gray-600/50' : ''
            }`}
            onClick={() => handleAppClick(app.label)}
            style={{ animationDelay: `${index * 50}ms` }}
          >
            <CardContent className="p-3 flex flex-col items-center justify-center h-20">
              <div className={`${app.color} mb-1`}>{app.icon}</div>
              <span className="text-xs text-center">{app.label}</span>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );

  const SettingsView = () => (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold mb-6">Settings</h2>
      
      {/* Network & Connectivity */}
      <Card className="bg-gray-800/50 backdrop-blur-sm border-gray-700">
        <CardContent className="p-4">
          <h3 className="text-lg font-semibold mb-4 flex items-center">
            <Globe className="mr-2 text-blue-400" size={20} />
            Network & Connectivity
          </h3>
          <div className="space-y-4">
            <div className="flex justify-between items-center cursor-pointer hover:bg-gray-700/30 p-2 rounded-lg"
                 onClick={() => alert('Wi-Fi Settings:\n• Connected to: Home_Network\n• Speed: 150 Mbps\n• Signal: Strong')}>
              <div className="flex items-center space-x-3">
                <Wifi className="text-blue-400" size={20} />
                <div>
                  <p className="font-medium">Wi-Fi</p>
                  <p className="text-sm text-gray-400">{systemInfo.network.speed}</p>
                </div>
              </div>
              <Badge variant={systemInfo.network.connected ? "default" : "secondary"}>
                {systemInfo.network.connected ? "Connected" : "Disconnected"}
              </Badge>
            </div>
            <div className="flex justify-between items-center cursor-pointer hover:bg-gray-700/30 p-2 rounded-lg"
                 onClick={toggleBluetooth}>
              <div className="flex items-center space-x-3">
                {systemInfo.bluetooth ? <Bluetooth className="text-blue-400" size={20} /> : <BluetoothOff className="text-gray-400" size={20} />}
                <div>
                  <p className="font-medium">Bluetooth</p>
                  <p className="text-sm text-gray-400">Device discovery</p>
                </div>
              </div>
              <Badge variant={systemInfo.bluetooth ? "default" : "secondary"}>
                {systemInfo.bluetooth ? "On" : "Off"}
              </Badge>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Display & Sound */}
      <Card className="bg-gray-800/50 backdrop-blur-sm border-gray-700">
        <CardContent className="p-4">
          <h3 className="text-lg font-semibold mb-4 flex items-center">
            <Smartphone className="mr-2 text-green-400" size={20} />
            Display & Sound
          </h3>
          <div className="space-y-4">
            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <span className="flex items-center">
                  <Sun size={16} className="mr-2" /> Brightness
                </span>
                <div className="flex items-center space-x-2">
                  <button onClick={() => adjustBrightness(-10)} className="text-gray-400 hover:text-white">-</button>
                  <span>{systemInfo.brightness}%</span>
                  <button onClick={() => adjustBrightness(10)} className="text-gray-400 hover:text-white">+</button>
                </div>
              </div>
              <div className="w-full bg-gray-700 rounded-full h-2 cursor-pointer" 
                   onClick={(e) => {
                     const rect = e.currentTarget.getBoundingClientRect();
                     const percent = ((e.clientX - rect.left) / rect.width) * 100;
                     setSystemInfo(prev => ({ ...prev, brightness: Math.round(percent) }));
                   }}>
                <div 
                  className="bg-yellow-500 h-2 rounded-full"
                  style={{ width: `${systemInfo.brightness}%` }}
                ></div>
              </div>
            </div>
            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <span className="flex items-center">
                  <Volume2 size={16} className="mr-2" /> Volume
                </span>
                <div className="flex items-center space-x-2">
                  <button onClick={() => adjustVolume(-10)} className="text-gray-400 hover:text-white">-</button>
                  <span>{systemInfo.volume}%</span>
                  <button onClick={() => adjustVolume(10)} className="text-gray-400 hover:text-white">+</button>
                </div>
              </div>
              <div className="w-full bg-gray-700 rounded-full h-2 cursor-pointer"
                   onClick={(e) => {
                     const rect = e.currentTarget.getBoundingClientRect();
                     const percent = ((e.clientX - rect.left) / rect.width) * 100;
                     setSystemInfo(prev => ({ ...prev, volume: Math.round(percent) }));
                   }}>
                <div 
                  className="bg-blue-500 h-2 rounded-full"
                  style={{ width: `${systemInfo.volume}%` }}
                ></div>
              </div>
            </div>
            <div className="flex justify-between items-center cursor-pointer hover:bg-gray-700/30 p-2 rounded-lg"
                 onClick={toggleDarkMode}>
              <div className="flex items-center space-x-3">
                {systemInfo.darkMode ? <Moon className="text-indigo-400" size={20} /> : <Sun className="text-yellow-400" size={20} />}
                <div>
                  <p className="font-medium">Dark Mode</p>
                  <p className="text-sm text-gray-400">System appearance</p>
                </div>
              </div>
              <Badge variant={systemInfo.darkMode ? "default" : "secondary"}>
                {systemInfo.darkMode ? "Dark" : "Light"}
              </Badge>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Security */}
      <Card className="bg-gray-800/50 backdrop-blur-sm border-gray-700">
        <CardContent className="p-4">
          <h3 className="text-lg font-semibold mb-4 flex items-center">
            <Shield className="mr-2 text-red-400" size={20} />
            Security & Privacy
          </h3>
          <div className="space-y-3">
            {[
              { label: "Screen Lock", value: "Fingerprint", icon: <Smartphone size={16} />, action: () => alert('Screen Lock Settings:\n• Fingerprint: Enabled\n• PIN: Set\n• Pattern: Available') },
              { label: "App Permissions", value: "Manage", icon: <Settings size={16} />, action: () => alert('App Permissions:\n• Camera: 5 apps\n• Location: 8 apps\n• Microphone: 3 apps') },
              { label: "Privacy Settings", value: "Configure", icon: <Shield size={16} />, action: () => alert('Privacy Settings:\n• Data Collection: Limited\n• Ad Tracking: Disabled\n• Analytics: Off') }
            ].map((item) => (
              <div key={item.label} className="flex justify-between items-center p-2 rounded-lg hover:bg-gray-700/30 cursor-pointer"
                   onClick={item.action}>
                <div className="flex items-center space-x-3">
                  <div className="text-gray-400">{item.icon}</div>
                  <span>{item.label}</span>
                </div>
                <div className="flex items-center space-x-2">
                  <span className="text-sm text-gray-400">{item.value}</span>
                  <ChevronRight size={16} className="text-gray-500" />
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );

  const AppsView = () => (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold mb-6">All Apps</h2>
      
      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
        <input 
          type="text" 
          placeholder="Search apps..." 
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="w-full bg-gray-800/50 border border-gray-700 rounded-lg pl-10 pr-4 py-3 text-white placeholder-gray-400 focus:outline-none focus:border-blue-500"
        />
      </div>

      {/* App Categories */}
      <div className="space-y-6">
        {[
          {
            category: "Productivity",
            apps: [
              { icon: <Calendar size={24} />, name: "Calendar", color: "text-orange-400" },
              { icon: <Mail size={24} />, name: "Mail", color: "text-red-400" },
              { icon: <Calculator size={24} />, name: "Calculator", color: "text-indigo-400" },
              { icon: <BookOpen size={24} />, name: "Notes", color: "text-yellow-400" }
            ]
          },
          {
            category: "Media",
            apps: [
              { icon: <Camera size={24} />, name: "Camera", color: "text-gray-400" },
              { icon: <Image size={24} />, name: "Gallery", color: "text-cyan-400" },
              { icon: <Music size={24} />, name: "Music", color: "text-pink-400" },
              { icon: <Video size={24} />, name: "Videos", color: "text-purple-400" }
            ]
          },
          {
            category: "Communication",
            apps: [
              { icon: <Phone size={24} />, name: "Phone", color: "text-green-500" },
              { icon: <MessageSquare size={24} />, name: "Messages", color: "text-blue-400" },
              { icon: <Users size={24} />, name: "Contacts", color: "text-teal-400" },
              { icon: <Bot size={24} />, name: "AI Chat", color: "text-purple-400" }
            ]
          },
          {
            category: "Utilities",
            apps: [
              { icon: <Folder size={24} />, name: "Files", color: "text-yellow-400" },
              { icon: <Cloud size={24} />, name: "Cloud", color: "text-blue-400" },
              { icon: <Navigation size={24} />, name: "Maps", color: "text-green-400" },
              { icon: <Settings size={24} />, name: "Settings", color: "text-gray-400" }
            ]
          }
        ].filter(section => 
          searchQuery === '' || 
          section.apps.some(app => 
            app.name.toLowerCase().includes(searchQuery.toLowerCase())
          )
        ).map((section) => (
          <div key={section.category}>
            <h3 className="text-lg font-semibold mb-3 text-gray-300">{section.category}</h3>
            <div className="grid grid-cols-4 gap-4">
              {section.apps.filter(app => 
                searchQuery === '' || 
                app.name.toLowerCase().includes(searchQuery.toLowerCase())
              ).map((app) => (
                <Card 
                  key={app.name}
                  className={`bg-gray-800/30 backdrop-blur-sm border-gray-700 transition-all duration-300 hover:bg-gray-700/50 hover:scale-110 cursor-pointer ${
                    selectedCard === app.name ? 'scale-95 bg-gray-600/50' : ''
                  }`}
                  onClick={() => handleAppClick(app.name)}
                >
                  <CardContent className="p-3 flex flex-col items-center justify-center h-20">
                    <div className={`${app.color} mb-1`}>{app.icon}</div>
                    <span className="text-xs text-center">{app.name}</span>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-black to-gray-900 text-white">
      {/* App Modal */}
      {showAppModal && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center">
          <div className="bg-gray-800 rounded-lg p-6 text-center animate-pulse">
            <div className="text-2xl mb-2">📱</div>
            <p className="text-lg">Opening {showAppModal}...</p>
          </div>
        </div>
      )}
      
      <div className="max-w-md mx-auto min-h-screen flex flex-col">
        {/* Main Content */}
        <div className="flex-1 p-4 pb-20">
          {currentView === 'home' && <HomeView />}
          {currentView === 'settings' && <SettingsView />}
          {currentView === 'apps' && <AppsView />}
        </div>

        {/* Bottom Navigation */}
        <div className="fixed bottom-0 left-1/2 transform -translate-x-1/2 w-full max-w-md">
          <div className="bg-gray-900/80 backdrop-blur-lg border-t border-gray-700 px-4 py-2">
            <div className="flex justify-around items-center">
              {[
                { id: 'home', icon: <Home size={20} />, label: 'Home' },
                { id: 'apps', icon: <Grid3X3 size={20} />, label: 'Apps' },
                { id: 'settings', icon: <Settings size={20} />, label: 'Settings' }
              ].map((item) => (
                <Button
                  key={item.id}
                  variant="ghost"
                  size="sm"
                  className={`flex flex-col items-center space-y-1 transition-all duration-200 ${
                    currentView === item.id 
                      ? 'text-blue-400 bg-blue-400/10' 
                      : 'text-gray-400 hover:text-white hover:bg-gray-800/50'
                  }`}
                  onClick={() => setCurrentView(item.id as any)}
                >
                  <div className={`transition-transform duration-200 ${
                    currentView === item.id ? 'scale-110' : ''
                  }`}>
                    {item.icon}
                  </div>
                  <span className="text-xs">{item.label}</span>
                </Button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;